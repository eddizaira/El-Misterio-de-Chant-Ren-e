import { useState } from 'react';
import { HomeScreen } from './components/HomeScreen';
import { InstructionsScreen } from './components/InstructionsScreen';
import { MusicScreen } from './components/MusicScreen';
import { IntroductionScreen } from './components/IntroductionScreen';
import { CharactersScreen } from './components/CharactersScreen';
import { InterrogationScreen } from './components/InterrogationScreen';
import { FinalMeetingScreen } from './components/FinalMeetingScreen';
import { ResultScreen } from './components/ResultScreen';

type Screen = 'home' | 'instructions' | 'music' | 'introduction' | 'characters' | 'interrogation' | 'finalmeeting' | 'result';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('home');
  const [selectedCharacter, setSelectedCharacter] = useState<string>('');
  const [accusedCharacter, setAccusedCharacter] = useState<string>('');

  const handleNavigate = (screen: string, data?: any) => {
    if (screen === 'interrogation' && data) {
      setSelectedCharacter(data);
    }
    if (screen === 'result' && data?.accused) {
      setAccusedCharacter(data.accused);
    }
    setCurrentScreen(screen as Screen);
  };

  return (
    <div className="relative w-full h-screen bg-[#0B0F14] overflow-hidden" style={{ maxWidth: '390px', maxHeight: '844px', margin: '0 auto' }}>
      {/* Google Fonts */}
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      <link href="https://fonts.googleapis.com/css2?family=Cinzel+Decorative:wght@400;700;900&family=Inter:wght@400;500;600&display=swap" rel="stylesheet" />
      
      {currentScreen === 'home' && <HomeScreen onNavigate={handleNavigate} />}
      {currentScreen === 'instructions' && <InstructionsScreen onNavigate={handleNavigate} />}
      {currentScreen === 'music' && <MusicScreen onNavigate={handleNavigate} />}
      {currentScreen === 'introduction' && <IntroductionScreen onNavigate={handleNavigate} />}
      {currentScreen === 'characters' && <CharactersScreen onNavigate={handleNavigate} />}
      {currentScreen === 'interrogation' && <InterrogationScreen characterId={selectedCharacter} onNavigate={handleNavigate} />}
      {currentScreen === 'finalmeeting' && <FinalMeetingScreen onNavigate={handleNavigate} />}
      {currentScreen === 'result' && <ResultScreen accusedId={accusedCharacter} onNavigate={handleNavigate} />}
    </div>
  );
}
