export interface Character {
  id: string;
  name: string;
  pumpkinVariant: 'kath' | 'nicole' | 'diego' | 'shanti' | 'kevin' | 'eddizaira';
  questions: {
    question: string;
    answers: string[];
    correctAnswer: number;
    reactions: string[];
  }[];
  clue: {
    item: string;
    description: string;
  };
}

export const victim = {
  id: 'josefrank',
  name: 'José Frank',
  pumpkinVariant: 'josefrank' as const
};

export const characters: Character[] = [
  {
    id: 'kath',
    name: 'Kath',
    pumpkinVariant: 'kath',
    questions: [
      {
        question: '¿Dónde estabas cuando sirvieron el chocolate?',
        answers: [
          'En la cocina, ayudando a preparar',
          'Junto a la chimenea',
          'Revisando mi teléfono en el sofá'
        ],
        correctAnswer: 0,
        reactions: [
          'Responde con seguridad',
          'Mira hacia la cocina nerviosamente',
          'Titubea ligeramente'
        ]
      },
      {
        question: '¿A quién viste cerca de José Frank?',
        answers: [
          'Nicole y Diego',
          'Shanti estaba a su lado',
          'Nadie, estaba solo'
        ],
        correctAnswer: 1,
        reactions: [
          'Se muestra confundida',
          'Asiente con claridad',
          'Evita el contacto visual'
        ]
      },
      {
        question: '¿Qué hiciste después del grito?',
        answers: [
          'Corrí hacia él',
          'Me quedé paralizada',
          'Busqué ayuda'
        ],
        correctAnswer: 0,
        reactions: [
          'Sus manos tiemblan',
          'Responde con voz quebrada',
          'Mantiene la compostura'
        ]
      }
    ],
    clue: {
      item: 'Taza intacta',
      description: 'Una taza con su nombre, sin tocar'
    }
  },
  {
    id: 'nicole',
    name: 'Nicole',
    pumpkinVariant: 'nicole',
    questions: [
      {
        question: '¿Dónde estabas cuando sirvieron el chocolate?',
        answers: [
          'En el baño',
          'Buscando leña afuera',
          'Sentada junto a José Frank'
        ],
        correctAnswer: 2,
        reactions: [
          'Cruza los brazos defensivamente',
          'Responde pero evita mirar a los ojos',
          'Se muestra tensa'
        ]
      },
      {
        question: '¿A quién viste cerca de José Frank?',
        answers: [
          'Todos estaban alrededor',
          'Diego le pasó la taza',
          'Kevin estaba de pie detrás'
        ],
        correctAnswer: 1,
        reactions: [
          'Parece dudar',
          'Titubea notablemente',
          'Asiente pero desvía la mirada'
        ]
      },
      {
        question: '¿Qué hiciste después del grito?',
        answers: [
          'Intenté ayudarlo',
          'Retrocedí asustada',
          'Grité por ayuda'
        ],
        correctAnswer: 1,
        reactions: [
          'Sus manos tiemblan ligeramente',
          'Mira hacia otro lado',
          'Su voz tiembla'
        ]
      }
    ],
    clue: {
      item: 'Bufanda',
      description: 'Una bufanda con manchas oscuras cerca de la escena'
    }
  },
  {
    id: 'diego',
    name: 'Diego',
    pumpkinVariant: 'diego',
    questions: [
      {
        question: '¿Dónde estabas cuando sirvieron el chocolate?',
        answers: [
          'Junto a la ventana',
          'Ayudando a servir las tazas',
          'En el sillón leyendo'
        ],
        correctAnswer: 1,
        reactions: [
          'Se muestra tranquilo',
          'Responde con seguridad',
          'Mantiene contacto visual'
        ]
      },
      {
        question: '¿A quién viste cerca de José Frank?',
        answers: [
          'Nicole estaba muy cerca',
          'Nadie en particular',
          'Shanti le ofreció algo'
        ],
        correctAnswer: 0,
        reactions: [
          'Asiente firmemente',
          'Parece seguro',
          'No duda al responder'
        ]
      },
      {
        question: '¿Qué hiciste después del grito?',
        answers: [
          'Llamé a emergencias',
          'Intenté reanimarlo',
          'Revisé la taza'
        ],
        correctAnswer: 2,
        reactions: [
          'Mira directamente',
          'Responde con calma',
          'No muestra nerviosismo aparente'
        ]
      }
    ],
    clue: {
      item: 'Libro',
      description: 'Un libro de química antigua en su mochila'
    }
  },
  {
    id: 'shanti',
    name: 'Shanti',
    pumpkinVariant: 'shanti',
    questions: [
      {
        question: '¿Dónde estabas cuando sirvieron el chocolate?',
        answers: [
          'Decorando la mesa',
          'Tomando fotos del lugar',
          'Hablando con Eddizaira'
        ],
        correctAnswer: 1,
        reactions: [
          'Sonríe nerviosamente',
          'Responde demasiado rápido',
          'Evita el contacto visual'
        ]
      },
      {
        question: '¿A quién viste cerca de José Frank?',
        answers: [
          'Diego le entregó la taza',
          'Kevin pasó junto a él',
          'Estaba rodeado de todos'
        ],
        correctAnswer: 2,
        reactions: [
          'Duda un momento',
          'Sus ojos delatan nerviosismo',
          'Titubea al explicar'
        ]
      },
      {
        question: '¿Qué hiciste después del grito?',
        answers: [
          'Solté mi cámara',
          'Corrí hacia él',
          'Me quedé en shock'
        ],
        correctAnswer: 2,
        reactions: [
          'Palidece visiblemente',
          'Su voz se quiebra',
          'Desvía la conversación'
        ]
      }
    ],
    clue: {
      item: 'Cámara',
      description: 'Fotos que muestran un frasco extraño en la mesa'
    }
  },
  {
    id: 'kevin',
    name: 'Kevin',
    pumpkinVariant: 'kevin',
    questions: [
      {
        question: '¿Dónde estabas cuando sirvieron el chocolate?',
        answers: [
          'Revisando la calefacción',
          'En la cocina',
          'Sentado cerca de la chimenea'
        ],
        correctAnswer: 0,
        reactions: [
          'Evita tu mirada',
          'Se muestra muy nervioso',
          'Tartamudea al responder'
        ]
      },
      {
        question: '¿A quién viste cerca de José Frank?',
        answers: [
          'Shanti',
          'Nicole le hablaba',
          'Estaba solo en ese momento'
        ],
        correctAnswer: 2,
        reactions: [
          'Titubea notablemente',
          'Responde demasiado rápido',
          'Se rasca el cuello nerviosamente'
        ]
      },
      {
        question: '¿Qué hiciste después del grito?',
        answers: [
          'Me acerqué lentamente',
          'Revisé si respiraba',
          'Llamé a todos'
        ],
        correctAnswer: 0,
        reactions: [
          'Palidece ligeramente',
          'Su voz tiembla',
          'Desvía la conversación rápidamente'
        ]
      }
    ],
    clue: {
      item: 'Herramientas',
      description: 'Un kit de herramientas con un frasco vacío dentro'
    }
  },
  {
    id: 'eddizaira',
    name: 'Eddizaira',
    pumpkinVariant: 'eddizaira',
    questions: [
      {
        question: '¿Dónde estabas cuando sirvieron el chocolate?',
        answers: [
          'Conversando con Shanti',
          'Revisando el botiquín',
          'En la sala con todos'
        ],
        correctAnswer: 2,
        reactions: [
          'Responde con claridad',
          'Se muestra serena',
          'Mantiene la compostura'
        ]
      },
      {
        question: '¿A quién viste cerca de José Frank?',
        answers: [
          'Diego y Nicole',
          'Kevin pasó cerca',
          'Todos estábamos alrededor'
        ],
        correctAnswer: 1,
        reactions: [
          'Parece segura',
          'Responde con detalle',
          'Mantiene contacto visual'
        ]
      },
      {
        question: '¿Qué hiciste después del grito?',
        answers: [
          'Intenté reanimarlo',
          'Busqué mi botiquín',
          'Revisé sus signos vitales'
        ],
        correctAnswer: 2,
        reactions: [
          'Te observa con seriedad',
          'Responde profesionalmente',
          'Muestra confianza'
        ]
      }
    ],
    clue: {
      item: 'Botiquín',
      description: 'Un botiquín con medicamentos faltantes'
    }
  }
];
