import { motion } from 'motion/react';
import { GameButton } from './GameButton';
import { ArrowLeft } from 'lucide-react';

interface MusicScreenProps {
  onNavigate: (screen: string) => void;
}

export function MusicScreen({ onNavigate }: MusicScreenProps) {
  return (
    <div className="relative h-full w-full bg-[#0B0F14] overflow-hidden">
      {/* Background texture */}
      <div className="absolute inset-0 opacity-10" style={{
        backgroundImage: 'repeating-linear-gradient(90deg, #1a1a1a 0px, #1a1a1a 2px, transparent 2px, transparent 4px)',
      }} />
      
      {/* Content */}
      <div className="relative z-10 h-full flex flex-col p-6">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="mb-6"
        >
          <button 
            onClick={() => onNavigate('home')}
            className="text-[#C7A76C] flex items-center gap-2 hover:opacity-80"
          >
            <ArrowLeft className="h-5 w-5" />
            Volver
          </button>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="flex-1 flex flex-col items-center justify-center"
        >
          {/* Gramophone illustration */}
          <motion.svg
            width="200"
            height="200"
            viewBox="0 0 200 200"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            initial={{ rotate: -5 }}
            animate={{ rotate: 5 }}
            transition={{ 
              duration: 3,
              repeat: Infinity,
              repeatType: "reverse",
              ease: "easeInOut"
            }}
            className="mb-8"
          >
            {/* Horn */}
            <path 
              d="M 100 80 Q 120 60 150 40 Q 160 35 170 40 Q 180 50 175 65 Q 170 75 155 85 L 100 80 Z" 
              fill="#C7A76C" 
              opacity="0.8"
            />
            <path 
              d="M 100 80 Q 120 60 150 40" 
              stroke="#d4b87f" 
              strokeWidth="2" 
              fill="none"
            />
            
            {/* Base/Box */}
            <rect 
              x="50" 
              y="100" 
              width="100" 
              height="60" 
              rx="5" 
              fill="#243140"
            />
            <rect 
              x="55" 
              y="105" 
              width="90" 
              height="50" 
              rx="3" 
              fill="#4B0D1F"
              opacity="0.5"
            />
            
            {/* Turntable */}
            <circle cx="100" cy="90" r="30" fill="#243140" />
            <circle cx="100" cy="90" r="25" fill="#0B0F14" />
            <circle cx="100" cy="90" r="5" fill="#C7A76C" />
            
            {/* Tone arm */}
            <line 
              x1="100" 
              y1="90" 
              x2="130" 
              y2="70" 
              stroke="#C7A76C" 
              strokeWidth="3"
              strokeLinecap="round"
            />
            <circle cx="130" cy="70" r="4" fill="#C7A76C" />
            
            {/* Decorative details */}
            <circle cx="70" cy="130" r="3" fill="#C7A76C" opacity="0.6" />
            <circle cx="130" cy="130" r="3" fill="#C7A76C" opacity="0.6" />
          </motion.svg>
          
          <h2 className="text-[#C7A76C] mb-6 text-center" style={{ fontFamily: 'Cinzel Decorative, serif' }}>
            Música Ambiental
          </h2>
          
          <div className="bg-[#243140]/50 backdrop-blur-sm p-6 rounded-lg border border-[#C7A76C]/30 max-w-sm">
            <p className="text-white/90 text-center leading-relaxed mb-4">
              Activa la música ambiental
            </p>
            <p className="text-[#C7A76C] text-center mb-6">
              <span className="italic">Winter Suspense Loop</span>
              <br />
              <span className="text-sm opacity-70">(YouTube)</span>
            </p>
            <p className="text-white/60 text-sm text-center">
              para mejorar la experiencia de juego
            </p>
          </div>
          
          <div className="mt-8 w-full max-w-xs">
            <GameButton 
              variant="primary"
              onClick={() => onNavigate('home')}
              className="w-full"
            >
              Volver al Menú
            </GameButton>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
