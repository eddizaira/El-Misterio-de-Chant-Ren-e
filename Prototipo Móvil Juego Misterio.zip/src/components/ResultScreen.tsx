import { motion } from "motion/react";
import { GameButton } from "./GameButton";
import { characters } from "../data/characters";
import { PumpkinCharacter } from "./PumpkinCharacter";
import { useState } from "react";

interface ResultScreenProps {
  accusedId: string;
  onNavigate: (screen: string) => void;
}

export function ResultScreen({
  accusedId,
  onNavigate,
}: ResultScreenProps) {
  // Randomly select the impostor (Kevin, Nicole, or Shanti)
  const [impostor] = useState(() => {
    const impostors = ["kevin", "nicole", "shanti"];
    return impostors[
      Math.floor(Math.random() * impostors.length)
    ];
  });

  const isCorrect = accusedId === impostor;
  const accusedCharacter = characters.find(
    (c) => c.id === accusedId,
  );
  const impostorCharacter = characters.find(
    (c) => c.id === impostor,
  );

  return (
    <div className="relative h-full w-full bg-[#0B0F14] overflow-hidden">
      {/* Background effect */}
      <motion.div
        className="absolute inset-0"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        style={{
          background: isCorrect
            ? "radial-gradient(circle at 50% 50%, #C7A76C 0%, #0B0F14 70%)"
            : "radial-gradient(circle at 50% 50%, #4B0D1F 0%, #0B0F14 70%)",
        }}
      />

      {/* Dramatic reveal animation */}
      <motion.div
        className="absolute inset-0 bg-black"
        initial={{ opacity: 1 }}
        animate={{ opacity: 0 }}
        transition={{ delay: 0.5, duration: 1 }}
      />

      {/* Content */}
      <div className="relative z-10 h-full flex flex-col items-center justify-center p-8">
        <motion.div
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 1.5, type: "spring" }}
          className="text-center max-w-sm"
        >
          {isCorrect ? (
            <>
              <motion.div
                animate={{
                  rotate: [0, 10, -10, 0],
                  scale: [1, 1.2, 1],
                }}
                transition={{
                  duration: 0.5,
                  delay: 2,
                  repeat: 2,
                }}
                className="text-7xl mb-6"
              >
                ✅
              </motion.div>

              <motion.h2
                className="text-[#C7A76C] mb-6"
                style={{
                  fontFamily: "Cinzel Decorative, serif",
                }}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 2 }}
              >
                ¡Caso Resuelto!
              </motion.h2>

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 2.5 }}
                className="space-y-4 mb-8"
              >
                <div className="mb-4 flex justify-center">
                  {impostorCharacter && (
                    <PumpkinCharacter
                      variant={impostorCharacter.pumpkinVariant}
                      size={120}
                    />
                  )}
                </div>
                <p className="text-white/90 leading-relaxed">
                  El engaño termina. El impostor era{" "}
                  <span className="text-[#C7A76C]">
                    {impostorCharacter?.name}
                  </span>
                  .
                </p>
                <p className="text-[#C7A76C]/80 text-sm italic">
                  El frío cede por un instante.
                </p>
              </motion.div>
            </>
          ) : (
            <>
              <motion.div
                animate={{
                  scale: [1, 1.1, 1],
                }}
                transition={{
                  duration: 1,
                  delay: 2,
                  repeat: 2,
                }}
                className="text-7xl mb-6"
              >
                ❌
              </motion.div>

              <motion.h2
                className="text-[#4B0D1F] mb-6"
                style={{
                  fontFamily: "Cinzel Decorative, serif",
                }}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 2 }}
              >
                Error Fatal
              </motion.h2>

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 2.5 }}
                className="space-y-4 mb-8"
              >
                <div className="mb-4 flex justify-center">
                  {accusedCharacter && (
                    <PumpkinCharacter
                      variant={accusedCharacter.pumpkinVariant}
                      size={120}
                    />
                  )}
                </div>
                <p className="text-white/90 leading-relaxed">
                  <span className="text-[#C7A76C]">
                    {accusedCharacter?.name}
                  </span>{" "}
                  niega todo…
                </p>
                <p className="text-white/80">
                  Las luces se apagan.
                </p>
                <p className="text-[#4B0D1F] italic">
                  El invierno reclama otra víctima.
                </p>
                <div className="mt-4 pt-4 border-t border-[#C7A76C]/30">
                  <div className="mb-3 flex justify-center">
                    {impostorCharacter && (
                      <PumpkinCharacter
                        variant={
                          impostorCharacter.pumpkinVariant
                        }
                        size={80}
                      />
                    )}
                  </div>
                  <p className="text-[#C7A76C]/60 text-sm">
                    El impostor era{" "}
                    <span className="text-[#C7A76C]">
                      {impostorCharacter?.name}
                    </span>
                  </p>
                </div>
              </motion.div>
            </>
          )}

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 3 }}
            className="space-y-3"
          >
            <GameButton
              variant="primary"
              onClick={() => onNavigate("home")}
              className="w-full"
            >
              Reiniciar Juego
            </GameButton>

            <GameButton
              variant="secondary"
              onClick={() => onNavigate("introduction")}
              className="w-full"
            >
              Otra Ronda
            </GameButton>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}