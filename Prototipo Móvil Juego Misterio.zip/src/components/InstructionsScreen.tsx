import { motion } from 'motion/react';
import { GameButton } from './GameButton';
import { ArrowLeft } from 'lucide-react';

interface InstructionsScreenProps {
  onNavigate: (screen: string) => void;
}

export function InstructionsScreen({ onNavigate }: InstructionsScreenProps) {
  return (
    <div className="relative h-full w-full bg-[#0B0F14] overflow-hidden">
      {/* Background texture */}
      <div className="absolute inset-0 opacity-10" style={{
        backgroundImage: 'repeating-linear-gradient(90deg, #1a1a1a 0px, #1a1a1a 2px, transparent 2px, transparent 4px)',
      }} />
      
      {/* Content */}
      <div className="relative z-10 h-full flex flex-col p-6">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="mb-6"
        >
          <button 
            onClick={() => onNavigate('home')}
            className="text-[#C7A76C] flex items-center gap-2 hover:opacity-80"
          >
            <ArrowLeft className="h-5 w-5" />
            Volver
          </button>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="flex-1 flex flex-col justify-center"
        >
          <h2 className="text-[#C7A76C] mb-8 text-center" style={{ fontFamily: 'Cinzel Decorative, serif' }}>
            Instrucciones
          </h2>
          
          <div className="bg-[#243140]/50 backdrop-blur-sm p-6 rounded-lg border border-[#C7A76C]/30 space-y-6">
            <div>
              <div className="text-[#C7A76C] mb-2 flex items-center gap-2">
                <span className="text-2xl">🎲</span>
                <span>Dados</span>
              </div>
              <p className="text-white/80">
                Usen un dado real antes de cada ronda. El número más bajo será interrogado primero.
              </p>
            </div>
            
            <div>
              <div className="text-[#C7A76C] mb-2 flex items-center gap-2">
                <span className="text-2xl">🤝</span>
                <span>Empates</span>
              </div>
              <p className="text-white/80">
                Si hay empate, ambos responden juntos.
              </p>
            </div>
            
            <div>
              <div className="text-[#C7A76C] mb-2 flex items-center gap-2">
                <span className="text-2xl">🔍</span>
                <span>Pistas</span>
              </div>
              <p className="text-white/80">
                Cada turno revela nuevas pistas. Observa las reacciones y busca contradicciones.
              </p>
            </div>
            
            <div>
              <div className="text-[#C7A76C] mb-2 flex items-center gap-2">
                <span className="text-2xl">⏰</span>
                <span>Objetivo</span>
              </div>
              <p className="text-white/80">
                Descubran quién envenenó a José Frank antes del amanecer.
              </p>
            </div>
          </div>
          
          <div className="mt-8">
            <GameButton 
              variant="primary"
              onClick={() => onNavigate('home')}
              className="w-full"
            >
              Entendido
            </GameButton>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
