import { motion } from 'motion/react';
import { GameButton } from './GameButton';

interface IntroductionScreenProps {
  onNavigate: (screen: string) => void;
}

export function IntroductionScreen({ onNavigate }: IntroductionScreenProps) {
  return (
    <div className="relative h-full w-full bg-[#0B0F14] overflow-hidden">
      {/* Vignette effect */}
      <div className="absolute inset-0" style={{
        background: 'radial-gradient(circle at center, #243140 0%, #0B0F14 70%)'
      }} />
      
      {/* Candlelight flicker effect */}
      <motion.div
        className="absolute inset-0"
        animate={{ 
          opacity: [0.3, 0.5, 0.3] 
        }}
        transition={{ 
          duration: 2,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        style={{
          background: 'radial-gradient(circle at 50% 50%, #C7A76C 0%, transparent 40%)',
        }}
      />
      
      {/* Content */}
      <div className="relative z-10 h-full flex flex-col items-center justify-between p-8 pt-16 pb-12">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1 }}
          className="flex-1 flex flex-col items-center justify-center text-center"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.3, type: "spring" }}
            className="text-6xl mb-8"
          >
            🏔️
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="space-y-6 max-w-sm"
          >
            <p className="text-white/90 leading-relaxed">
              Noche fría en <span className="text-[#C7A76C]" style={{ fontFamily: 'Cinzel Decorative, serif' }}>Chant Renée</span>.
            </p>
            
            <p className="text-white/90 leading-relaxed">
              Afuera, la tormenta azota las ventanas.
            </p>
            
            <p className="text-white/90 leading-relaxed">
              Entre risas y tazas de chocolate caliente,
              <br />
              <span className="text-[#C7A76C]">José Frank</span> se lleva la taza a los labios…
            </p>
            
            <motion.p 
              className="text-[#4B0D1F]"
              animate={{ 
                opacity: [0.6, 1, 0.6]
              }}
              transition={{ 
                duration: 2,
                repeat: Infinity 
              }}
            >
              Un golpe seco.
            </motion.p>
            
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1.2 }}
              className="pt-4 space-y-3"
            >
              <p className="text-white/80">
                El silencio se instala.
              </p>
              <p className="text-[#C7A76C] text-lg">
                Hay un envenenador entre ustedes.
              </p>
            </motion.div>
          </motion.div>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.5 }}
          className="w-full max-w-xs"
        >
          <GameButton 
            variant="accent"
            onClick={() => onNavigate('characters')}
            className="w-full"
          >
            Comenzar Investigación
          </GameButton>
        </motion.div>
      </div>
    </div>
  );
}
