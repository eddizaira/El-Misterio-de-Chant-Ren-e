import { motion } from 'motion/react';
import { GameButton } from './GameButton';
import { Search } from 'lucide-react';
import { characters, victim } from '../data/characters';
import { PumpkinCharacter } from './PumpkinCharacter';

interface CharactersScreenProps {
  onNavigate: (screen: string, characterId?: string) => void;
}

export function CharactersScreen({ onNavigate }: CharactersScreenProps) {
  return (
    <div className="relative h-full w-full bg-[#0B0F14] overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 opacity-10" style={{
        backgroundImage: 'repeating-linear-gradient(90deg, #1a1a1a 0px, #1a1a1a 2px, transparent 2px, transparent 4px)',
      }} />
      
      {/* Header */}
      <div className="relative z-10 p-6 pb-4 border-b border-[#C7A76C]/30">
        <h2 className="text-[#C7A76C] text-center" style={{ fontFamily: 'Cinzel Decorative, serif' }}>
          Sospechosos
        </h2>
        <p className="text-[#C7A76C]/60 text-sm text-center mt-2">
          Tira los dados antes de continuar
        </p>
      </div>
      
      {/* Characters grid */}
      <div className="relative z-10 h-[calc(100%-240px)] overflow-y-auto p-6 pt-4">
        <div className="grid grid-cols-2 gap-4 max-w-sm mx-auto">
          {/* Victim first */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="col-span-2 bg-[#243140]/40 backdrop-blur-sm rounded-lg border-2 border-[#4B0D1F]/50 p-4 flex flex-col items-center"
          >
            <PumpkinCharacter variant={victim.pumpkinVariant} size={100} isVictim={true} />
            <h3 className="text-[#C7A76C]/60 mt-3 text-center line-through">{victim.name}</h3>
            <p className="text-[#4B0D1F] text-sm mt-1">VÍCTIMA</p>
          </motion.div>
          
          {/* Living characters */}
          {characters.map((character, index) => (
            <motion.div
              key={character.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: (index + 1) * 0.1 }}
              className="bg-[#243140]/70 backdrop-blur-sm rounded-lg border border-[#C7A76C]/30 p-4 flex flex-col items-center"
            >
              <PumpkinCharacter variant={character.pumpkinVariant} size={100} />
              <h3 className="text-[#C7A76C] mt-3 mb-3 text-center">{character.name}</h3>
              <GameButton
                variant="secondary"
                onClick={() => onNavigate('interrogation', character.id)}
                className="w-full text-sm py-2"
              >
                <Search className="inline-block mr-1 h-3 w-3" />
                Interrogar
              </GameButton>
            </motion.div>
          ))}
        </div>
      </div>
      
      {/* Bottom action */}
      <div className="relative z-10 p-6 pt-4 border-t border-[#C7A76C]/30 bg-[#0B0F14]">
        <GameButton
          variant="accent"
          onClick={() => onNavigate('finalmeeting')}
          className="w-full"
        >
          Reunión Final
        </GameButton>
      </div>
    </div>
  );
}
