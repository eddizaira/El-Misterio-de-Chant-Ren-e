import { motion, AnimatePresence } from 'motion/react';
import { GameButton } from './GameButton';
import { ArrowLeft, Search } from 'lucide-react';
import { characters, Character } from '../data/characters';
import { PumpkinCharacter } from './PumpkinCharacter';
import { useState } from 'react';

interface InterrogationScreenProps {
  characterId: string;
  onNavigate: (screen: string) => void;
}

export function InterrogationScreen({ characterId, onNavigate }: InterrogationScreenProps) {
  const character = characters.find(c => c.id === characterId) as Character;
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showReaction, setShowReaction] = useState(false);
  const [showClue, setShowClue] = useState(false);
  
  const handleAnswerSelect = (answerIndex: number) => {
    setSelectedAnswer(answerIndex);
    setShowReaction(true);
    
    setTimeout(() => {
      setShowReaction(false);
      setSelectedAnswer(null);
      if (currentQuestion < character.questions.length - 1) {
        setCurrentQuestion(currentQuestion + 1);
      }
    }, 2500);
  };
  
  return (
    <div className="relative h-full w-full bg-[#0B0F14] overflow-hidden">
      {/* Candlelight effect */}
      <motion.div
        className="absolute inset-0"
        animate={{ 
          opacity: [0.2, 0.4, 0.2] 
        }}
        transition={{ 
          duration: 3,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        style={{
          background: 'radial-gradient(circle at 50% 30%, #C7A76C 0%, transparent 50%)',
        }}
      />
      
      {/* Header */}
      <div className="relative z-10 p-6 pb-4 flex items-center justify-between border-b border-[#C7A76C]/30">
        <button 
          onClick={() => onNavigate('characters')}
          className="text-[#C7A76C] flex items-center gap-2 hover:opacity-80"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h2 className="text-[#C7A76C]" style={{ fontFamily: 'Cinzel Decorative, serif' }}>
          {character.name}
        </h2>
        <button 
          onClick={() => setShowClue(true)}
          className="text-[#C7A76C] hover:text-[#d4b87f] transition-colors"
        >
          <Search className="h-5 w-5" />
        </button>
      </div>
      
      {/* Content */}
      <div className="relative z-10 h-[calc(100%-88px)] flex flex-col items-center justify-center p-6">
        <AnimatePresence mode="wait">
          {!showReaction ? (
            <motion.div
              key={`question-${currentQuestion}`}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="w-full max-w-sm"
            >
              <div className="flex justify-center mb-8">
                <PumpkinCharacter variant={character.pumpkinVariant} size={120} />
              </div>
              
              <div className="bg-[#243140]/70 backdrop-blur-sm rounded-lg border border-[#C7A76C]/30 p-6 mb-6">
                <p className="text-white text-center mb-2">
                  Pregunta {currentQuestion + 1} de {character.questions.length}
                </p>
                <h3 className="text-[#C7A76C] text-center mb-6">
                  {character.questions[currentQuestion].question}
                </h3>
                
                <div className="space-y-3">
                  {character.questions[currentQuestion].answers.map((answer, index) => (
                    <GameButton
                      key={index}
                      variant="secondary"
                      onClick={() => handleAnswerSelect(index)}
                      className="w-full text-left text-sm"
                    >
                      {answer}
                    </GameButton>
                  ))}
                </div>
              </div>
              
              <div className="text-center text-[#C7A76C]/60 text-sm">
                {currentQuestion === character.questions.length - 1 
                  ? 'Última pregunta' 
                  : 'Selecciona una respuesta'}
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="reaction"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="w-full max-w-sm text-center"
            >
              <motion.div
                animate={{ rotate: [0, 5, -5, 0] }}
                transition={{ duration: 0.5, repeat: 2 }}
                className="mb-6 flex justify-center"
              >
                <PumpkinCharacter variant={character.pumpkinVariant} size={120} />
              </motion.div>
              
              <div className="bg-[#4B0D1F]/70 backdrop-blur-sm rounded-lg border border-[#C7A76C]/50 p-6">
                <p className="text-[#C7A76C] text-lg italic">
                  "{character.questions[currentQuestion].reactions[selectedAnswer!]}"
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      
      {/* Clue overlay */}
      {showClue && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="absolute inset-0 bg-black/90 flex items-center justify-center p-8 z-20"
          onClick={() => setShowClue(false)}
        >
          <div className="bg-[#243140] p-8 rounded-lg border border-[#C7A76C] max-w-sm text-center">
            <div className="text-5xl mb-4">🔍</div>
            <h3 className="text-[#C7A76C] mb-3">Pista encontrada</h3>
            <p className="text-white/80 text-sm mb-2">{character.clue.item}</p>
            <p className="text-white mb-6">
              {character.clue.description}
            </p>
            <GameButton 
              variant="primary"
              onClick={() => setShowClue(false)}
              className="w-full"
            >
              Cerrar
            </GameButton>
          </div>
        </motion.div>
      )}
    </div>
  );
}
