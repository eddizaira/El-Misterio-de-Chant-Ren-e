interface PumpkinCharacterProps {
  variant: 'kath' | 'nicole' | 'josefrank' | 'diego' | 'shanti' | 'kevin' | 'eddizaira';
  size?: number;
  isVictim?: boolean;
}

export function PumpkinCharacter({ variant, size = 120, isVictim = false }: PumpkinCharacterProps) {
  const opacity = isVictim ? 0.4 : 1;
  
  // Base pumpkin head
  const BasePumpkin = () => (
    <>
      {/* Main pumpkin shape */}
      <ellipse cx="60" cy="60" rx="45" ry="50" fill="#C7A76C" opacity={opacity} />
      <ellipse cx="60" cy="60" rx="42" ry="47" fill="#d4b87f" opacity={opacity} />
      
      {/* Pumpkin lines */}
      <path d="M 60 10 Q 55 60 60 110" stroke="#C7A76C" strokeWidth="2" fill="none" opacity={opacity * 0.5} />
      <path d="M 60 10 Q 65 60 60 110" stroke="#C7A76C" strokeWidth="2" fill="none" opacity={opacity * 0.5} />
      <path d="M 40 30 Q 50 60 45 95" stroke="#C7A76C" strokeWidth="1.5" fill="none" opacity={opacity * 0.3} />
      <path d="M 80 30 Q 70 60 75 95" stroke="#C7A76C" strokeWidth="1.5" fill="none" opacity={opacity * 0.3} />
      
      {/* Eyes */}
      <ellipse cx="45" cy="50" rx="6" ry="8" fill="#243140" opacity={opacity} />
      <ellipse cx="75" cy="50" rx="6" ry="8" fill="#243140" opacity={opacity} />
      
      {/* Nose */}
      <path d="M 60 60 L 55 70 L 65 70 Z" fill="#243140" opacity={opacity} />
      
      {/* Mouth */}
      <path d="M 40 75 Q 60 85 80 75" stroke="#243140" strokeWidth="3" fill="none" opacity={opacity} strokeLinecap="round" />
    </>
  );
  
  return (
    <svg width={size} height={size} viewBox="0 0 120 120" fill="none" xmlns="http://www.w3.org/2000/svg">
      <BasePumpkin />
      
      {/* Character-specific accessories */}
      {variant === 'kath' && (
        <>
          {/* Bow/ribbon */}
          <path d="M 40 20 Q 35 15 30 20 Q 35 18 40 20" fill="#4B0D1F" opacity={opacity} />
          <path d="M 50 20 Q 55 15 60 20 Q 55 18 50 20" fill="#4B0D1F" opacity={opacity} />
          <circle cx="45" cy="20" r="4" fill="#4B0D1F" opacity={opacity} />
        </>
      )}
      
      {variant === 'nicole' && (
        <>
          {/* Scarf */}
          <rect x="20" y="90" width="80" height="15" rx="3" fill="#4B0D1F" opacity={opacity} />
          <rect x="25" y="92" width="70" height="3" fill="#C7A76C" opacity={opacity * 0.5} />
          <rect x="25" y="98" width="70" height="3" fill="#C7A76C" opacity={opacity * 0.5} />
        </>
      )}
      
      {variant === 'josefrank' && (
        <>
          {/* Glasses (broken for victim) */}
          <circle cx="45" cy="50" r="10" stroke="#243140" strokeWidth="2" fill="none" opacity={opacity} />
          <circle cx="75" cy="50" r="10" stroke="#243140" strokeWidth="2" fill="none" opacity={opacity} />
          <line x1="55" y1="50" x2="65" y2="50" stroke="#243140" strokeWidth="2" opacity={opacity} />
          {isVictim && <line x1="40" y1="45" x2="85" y2="55" stroke="#4B0D1F" strokeWidth="3" opacity={0.7} />}
        </>
      )}
      
      {variant === 'diego' && (
        <>
          {/* Winter hat */}
          <ellipse cx="60" cy="15" rx="35" ry="12" fill="#243140" opacity={opacity} />
          <rect x="30" y="8" width="60" height="15" fill="#243140" opacity={opacity} />
          <circle cx="60" cy="5" r="6" fill="#C7A76C" opacity={opacity} />
        </>
      )}
      
      {variant === 'shanti' && (
        <>
          {/* Flower accessory */}
          <circle cx="85" cy="30" r="8" fill="#4B0D1F" opacity={opacity} />
          <circle cx="80" cy="25" r="5" fill="#C7A76C" opacity={opacity} />
          <circle cx="90" cy="25" r="5" fill="#C7A76C" opacity={opacity} />
          <circle cx="80" cy="35" r="5" fill="#C7A76C" opacity={opacity} />
          <circle cx="90" cy="35" r="5" fill="#C7A76C" opacity={opacity} />
        </>
      )}
      
      {variant === 'kevin' && (
        <>
          {/* Tool/wrench */}
          <rect x="90" y="50" width="15" height="4" fill="#243140" opacity={opacity} />
          <circle cx="100" cy="52" r="6" stroke="#243140" strokeWidth="2" fill="none" opacity={opacity} />
        </>
      )}
      
      {variant === 'eddizaira' && (
        <>
          {/* Medical cross */}
          <rect x="88" y="45" width="4" height="14" fill="#4B0D1F" opacity={opacity} />
          <rect x="83" y="50" width="14" height="4" fill="#4B0D1F" opacity={opacity} />
        </>
      )}
      
      {/* Victim X mark */}
      {isVictim && (
        <>
          <line x1="30" y1="30" x2="90" y2="90" stroke="#4B0D1F" strokeWidth="4" opacity={0.6} />
          <line x1="90" y1="30" x2="30" y2="90" stroke="#4B0D1F" strokeWidth="4" opacity={0.6} />
        </>
      )}
    </svg>
  );
}
