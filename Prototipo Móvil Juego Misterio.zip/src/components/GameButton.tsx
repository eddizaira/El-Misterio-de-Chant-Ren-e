import { motion } from 'motion/react';

interface GameButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'secondary' | 'accent';
  className?: string;
}

export function GameButton({ children, onClick, variant = 'primary', className = '' }: GameButtonProps) {
  const baseClasses = "px-6 py-3 rounded-lg transition-all duration-300 shadow-lg";
  
  const variantClasses = {
    primary: "bg-[#C7A76C] text-[#0B0F14] hover:bg-[#d4b87f]",
    secondary: "bg-[#243140] text-[#C7A76C] hover:bg-[#2d3d4f] border border-[#C7A76C]",
    accent: "bg-[#4B0D1F] text-[#C7A76C] hover:bg-[#5d1127] border border-[#C7A76C]"
  };
  
  return (
    <motion.button
      whileTap={{ scale: 0.95 }}
      whileHover={{ scale: 1.02 }}
      onClick={onClick}
      className={`${baseClasses} ${variantClasses[variant]} ${className}`}
    >
      {children}
    </motion.button>
  );
}
