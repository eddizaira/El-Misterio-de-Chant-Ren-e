import { motion } from 'motion/react';
import { GameButton } from './GameButton';
import { Music, Info } from 'lucide-react';

interface HomeScreenProps {
  onNavigate: (screen: string) => void;
}

export function HomeScreen({ onNavigate }: HomeScreenProps) {
  
  return (
    <div className="relative h-full w-full bg-[#0B0F14] overflow-hidden">
      {/* Background texture */}
      <div className="absolute inset-0 opacity-20" style={{
        backgroundImage: 'repeating-linear-gradient(90deg, #1a1a1a 0px, #1a1a1a 2px, transparent 2px, transparent 4px)',
      }} />
      
      {/* Vignette effect */}
      <div className="absolute inset-0" style={{
        background: 'radial-gradient(circle, transparent 30%, #0B0F14 100%)'
      }} />
      
      {/* Snowfall effect */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-white rounded-full"
            initial={{ 
              x: Math.random() * 390, 
              y: -10,
              opacity: 0.3 + Math.random() * 0.7 
            }}
            animate={{ 
              y: 844,
              x: Math.random() * 390
            }}
            transition={{ 
              duration: 5 + Math.random() * 5,
              repeat: Infinity,
              delay: Math.random() * 5
            }}
          />
        ))}
      </div>
      
      {/* Content */}
      <div className="relative z-10 h-full flex flex-col items-center justify-between p-8 pt-24 pb-12">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          className="flex-1 flex flex-col items-center justify-center text-center"
        >
          {/* Logo/Title */}
          <div className="mb-8">
            <h1 className="text-[#C7A76C] mb-2" style={{ fontFamily: 'Cinzel Decorative, serif' }}>
              El Misterio de<br/>Chant Renée
            </h1>
            <motion.div
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="text-4xl text-center"
            >
              ❄️
            </motion.div>
          </div>
          
          <p className="text-[#C7A76C] opacity-80 mb-12 max-w-xs">
            Una noche de chocolate y traición
          </p>
          
          {/* Main buttons */}
          <div className="space-y-4 w-full max-w-xs">
            <GameButton 
              variant="primary"
              onClick={() => onNavigate('introduction')}
              className="w-full"
            >
              Comenzar Juego
            </GameButton>
            
            <GameButton 
              variant="secondary"
              onClick={() => onNavigate('instructions')}
              className="w-full"
            >
              <Info className="inline-block mr-2 h-4 w-4" />
              Instrucciones
            </GameButton>
            
            <GameButton 
              variant="accent"
              onClick={() => onNavigate('music')}
              className="w-full"
            >
              <Music className="inline-block mr-2 h-4 w-4" />
              Créditos / Música
            </GameButton>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
