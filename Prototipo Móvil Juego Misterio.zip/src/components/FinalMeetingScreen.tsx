import { motion } from 'motion/react';
import { GameButton } from './GameButton';
import { ArrowLeft } from 'lucide-react';
import { characters } from '../data/characters';
import { PumpkinCharacter } from './PumpkinCharacter';

interface FinalMeetingScreenProps {
  onNavigate: (screen: string, data?: any) => void;
}

export function FinalMeetingScreen({ onNavigate }: FinalMeetingScreenProps) {
  const handleAccusation = (characterId: string) => {
    onNavigate('result', { accused: characterId });
  };
  
  return (
    <div className="relative h-full w-full bg-[#0B0F14] overflow-hidden">
      {/* Fire glow effect */}
      <motion.div
        className="absolute inset-0"
        animate={{ 
          opacity: [0.3, 0.6, 0.3] 
        }}
        transition={{ 
          duration: 2,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        style={{
          background: 'radial-gradient(circle at 50% 80%, #4B0D1F 0%, transparent 60%)',
        }}
      />
      
      {/* Header */}
      <div className="relative z-10 p-6 pb-4 flex items-center justify-between border-b border-[#C7A76C]/30">
        <button 
          onClick={() => onNavigate('characters')}
          className="text-[#C7A76C] flex items-center gap-2 hover:opacity-80"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h2 className="text-[#C7A76C]" style={{ fontFamily: 'Cinzel Decorative, serif' }}>
          Reunión Final
        </h2>
        <div className="w-5" />
      </div>
      
      {/* Content */}
      <div className="relative z-10 h-[calc(100%-88px)] overflow-y-auto p-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-sm mx-auto"
        >
          <div className="text-center mb-8">
            <div className="text-5xl mb-4">🔥</div>
            <p className="text-white/90 leading-relaxed mb-4">
              Todos se reúnen alrededor de la chimenea.
            </p>
            <p className="text-[#C7A76C] leading-relaxed mb-4">
              Es hora de acusar al posible impostor.
            </p>
            <p className="text-[#C7A76C]/60 text-sm mb-2">
              Tira el dado para decidir quién acusa primero.
            </p>
            <p className="text-[#4B0D1F] text-sm">
              El amanecer está cerca. Elige sabiamente.
            </p>
          </div>
          
          <div className="bg-[#243140]/50 backdrop-blur-sm rounded-lg border border-[#C7A76C]/30 p-4 mb-6">
            <h3 className="text-[#C7A76C] text-center mb-4">¿Quién es el culpable?</h3>
            
            <div className="space-y-2">
              {characters.map((character, index) => (
                <motion.div
                  key={character.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <GameButton
                    variant="accent"
                    onClick={() => handleAccusation(character.id)}
                    className="w-full flex items-center justify-start gap-3 py-3"
                  >
                    <div className="flex-shrink-0">
                      <PumpkinCharacter variant={character.pumpkinVariant} size={32} />
                    </div>
                    <span>Acusar a {character.name}</span>
                  </GameButton>
                </motion.div>
              ))}
            </div>
          </div>
          
          <div className="text-center text-[#C7A76C]/60 text-sm">
            Una vez que acuses, no hay vuelta atrás
          </div>
        </motion.div>
      </div>
    </div>
  );
}
