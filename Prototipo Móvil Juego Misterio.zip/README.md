
  # Prototipo Móvil Juego Misterio

  This is a code bundle for Prototipo Móvil Juego Misterio. The original project is available at https://www.figma.com/design/Q7GSTDDOKeal9BledJ9XsA/Prototipo-M%C3%B3vil-Juego-Misterio.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  